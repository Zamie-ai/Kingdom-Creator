# Kingdom Creator Android project

This is the portrait-locked Android WebView wrapper for Kingdom Creator. The game is bundled locally at `app/src/main/assets/index.html`.

## Build an APK on a computer

Open this folder in Android Studio and build `app` (Gradle 8.9, JDK 17, Android SDK 35).

## Build an APK without a computer (GitHub Actions)

This project includes `.github/workflows/build-apk.yml`.

1. Create/sign in to a GitHub account and create a **private** repository.
2. Upload the contents of this folder to the repository's `main` branch (the `.github` folder must be included).
3. In the repository, open **Actions** and enable workflows if prompted.
4. Select **Build Kingdom Creator APK** and tap **Run workflow**.
5. When the run finishes successfully, open that run and download the artifact named `Kingdom-Creator-debug-apk`.
6. Extract the artifact ZIP on your phone. Install `app-debug.apk`.

The workflow produces a debug APK for personal installation/testing. It does not create a Play Store release or a signed release APK. GitHub account/repository setup and upload are still required; this ZIP alone is not an APK.
